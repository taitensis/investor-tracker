import { useState } from 'react'
import { supabase } from './supabaseClient'

export default function AssetForm({ onCreated }) {
  const [isin, setIsin] = useState('')
  const [name, setName] = useState('')
  const [type, setType] = useState('stock')
  const [currency, setCurrency] = useState('EUR')
  const [lsPath, setLsPath] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
  
    const user = (await supabase.auth.getUser()).data.user
  
    const { error } = await supabase.from('asset').insert([
      {
        user_id: user.id, // ✅ required for RLS to pass
        isin,
        name,
        type,
        currency,
        ls_path: lsPath
      }
    ])
  
    if (!error) {
      setIsin('')
      setName('')
      setLsPath('')
      onCreated?.()
    }
  
    setLoading(false)
  }  

  return (
    <form onSubmit={handleSubmit} className="p-4 border rounded space-y-2 bg-white shadow max-w-md mx-auto mt-6">
      <h3 className="text-lg font-semibold">Add Asset</h3>
      <input
        className="w-full border p-2 rounded"
        placeholder="ISIN (e.g. US0378331005)"
        value={isin}
        onChange={(e) => setIsin(e.target.value.toUpperCase())}
        required
      />
      <input
        className="w-full border p-2 rounded"
        placeholder="Name (e.g. Apple Inc)"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <select className="w-full border p-2 rounded" value={type} onChange={(e) => setType(e.target.value)}>
        <option value="stock">Stock</option>
        <option value="ETF">ETF</option>
        <option value="crypto">Crypto</option>
        <option value="option">Option</option>
        <option value="derivative">Derivative</option>
      </select>
      <input
        className="w-full border p-2 rounded"
        placeholder="Currency (EUR, USD...)"
        value={currency}
        onChange={(e) => setCurrency(e.target.value.toUpperCase())}
      />
      <input
        className="w-full border p-2 rounded"
        placeholder="LS Path (e.g. apple-aktie or 1880816)"
        value={lsPath}
        onChange={(e) => setLsPath(e.target.value)}
      />
      <button
        type="submit"
        disabled={loading}
        className="w-full bg-green-600 text-white p-2 rounded"
      >
        {loading ? 'Saving…' : 'Save Asset'}
      </button>
    </form>
  )
}