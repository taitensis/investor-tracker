import { createContext, useContext, useState, useCallback } from 'react'
import { createPortal } from 'react-dom'

// Create a context for the toast system
const ToastContext = createContext()

// Custom hook to use the toast
export function useToast() {
  return useContext(ToastContext)
}

// The main provider component
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])

  // Function to show a toast
  const addToast = useCallback((message) => {
    console.log('Triggering toast:', message) // Debug log
    const id = Date.now()
    setToasts((prev) => [...prev, { id, message }])
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id))
    }, 3000) // Toast disappears after 3 seconds
  }, [])

  // The actual toast elements that appear on the screen
  const toastElements = (
    <div className="fixed top-4 right-4 flex flex-col space-y-2 z-[9999] w-[300px]">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="bg-green-600 text-white px-4 py-2 rounded-xl shadow-md animate-slide-in cursor-pointer"
          onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
        >
          {toast.message}
        </div>
      ))}
    </div>
  )

  // Wrap children and inject the toasts into the body
  return (
    <ToastContext.Provider value={addToast}>
      {children}
      {createPortal(toastElements, document.body)}
    </ToastContext.Provider>
  )
}
