import PositionList from './PositionList'

export default function Overview() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-2">Portfolio Overview</h2>
      <PositionList filterByAccount={null} />
    </div>
  )
}
