import { useState } from 'react'
import Overview from './Overview'
import PEA from './PEA'
import CTO from './CTO'
import { useToast } from './ToastProvider'

export default function App() {
    const toast = useToast()
    const [activeTab, setActiveTab] = useState('overview')
    
    return (
        <div className="min-h-screen bg-gray-100 text-gray-800">
          {/* Top bar with buttons */}
          <div className="bg-white shadow-md p-4 flex space-x-4 justify-center border-b">
            {/* Toast trigger button */}
            <button
              onClick={() => toast('✅ Toast from App')}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition"
            >
              Trigger Toast
            </button>
      
            {/* Navigation buttons */}
            <button
              className={`px-4 py-2 rounded-lg transition ${
                activeTab === 'overview'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
              }`}
              onClick={() => setActiveTab('overview')}
            >
              Overview
            </button>
            <button
              className={`px-4 py-2 rounded-lg transition ${
                activeTab === 'pea'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
              }`}
              onClick={() => setActiveTab('pea')}
            >
              PEA
            </button>
            <button
              className={`px-4 py-2 rounded-lg transition ${
                activeTab === 'cto'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
              }`}
              onClick={() => setActiveTab('cto')}
            >
              CTO
            </button>
          </div>
      
          {/* Content area */}
          <div className="p-4">
            {activeTab === 'overview' && <Overview />}
            {activeTab === 'pea' && <PEA />}
            {activeTab === 'cto' && <CTO />}
          </div>
        </div>
      )      
}